package org.eclipse.papyrus.moka.animation.engine;

public enum AnimationKind {
	ANIMATED,
	SUSPENDED,
	VISITED
}
